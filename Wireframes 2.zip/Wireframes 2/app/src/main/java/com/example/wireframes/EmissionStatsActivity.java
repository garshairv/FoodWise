package com.example.wireframes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmissionStatsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emission_stats);
    }
}